# FormCoach v2 – AI + MediaPipe Analiza Techniki

Analiza techniki ćwiczeń w czasie rzeczywistym:
- **MediaPipe** śledzi 33 punkty ciała i mierzy kąty stawów na żywo
- **Claude Vision AI** analizuje obraz + dane liczbowe co ~4 sekundy
- Szkielet rysowany na żywo na podglądzie kamery
- Kąty oznaczone kolorami: 🟢 dobry / 🔴 do poprawy

## Ćwiczenia
🏋️ Przysiad · 💪 Pompki · 🦵 Wykroki · 🧱 Deska · 🔝 Podciąganie

## Deployment na Netlify

### 1. Wgraj projekt na Netlify
Wrzuć cały folder (drag & drop lub przez GitHub).

### 2. Ustaw zmienną środowiskową
Netlify → Site Settings → Environment Variables:
```
ANTHROPIC_API_KEY = twój_klucz_api
```

### 3. Build settings (z netlify.toml – automatyczne)
- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`

## Lokalne testowanie
```bash
npm install
npm run dev   # uruchamia netlify dev (wymagany dla Functions)
```
Otwórz: http://localhost:8888

## WAŻNE – HTTPS
MediaPipe wymaga HTTPS lub localhost.
Na Netlify działa od razu. Lokalnie używaj `netlify dev`.

## Struktura
```
form-coach-v2/
├── netlify/functions/analyze.js   ← proxy Claude API
├── src/
│   ├── App.jsx                    ← główna aplikacja
│   ├── main.jsx
│   └── poseAnalyzer.js            ← obliczanie kątów MediaPipe
├── index.html                     ← ładuje MediaPipe z CDN
├── package.json
├── vite.config.js
└── netlify.toml
```
